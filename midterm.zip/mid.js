var input="";
var mytop=0
var myleft=0
var mybgimg= document.getElementById("background")

document.getElementById("menu").addEventListener("click", function(){
    document.getElementById("controls").style.bottom = "0px";
});



document.getElementById("background").addEventListener("keydown", function(ev){
    if (ev.keyCode== 107){
        document.getElementById("background").style.width += "10px";
        document.getElementById("background").style.height += "10px";
    } else if(ev.keyCode== 109){
        document.getElementById("background").style.width -= "10px";
        document.getElementById("background").style.height -= "10px";
    }
});


document.getElementById("background").addEventListener("keydown",function(ev){
    if(ev.keyCode == 38)
        {
            mytop=mytop-10;
            mybgimg.style.top=mytop+"10px";
        }
    else if(ev.keyCode == 40)
        {
            mytop=mytop+10;
            mybgimg.style.top=mytop+"10px";
        }
    else if(ev.keyCode == 37)
        {
            myleft=myleft-10;
            mybgimg.style.left=myleft+"10px";
        }
    else if(ev.keyCode == 39)
        {
            myleft=myleft+10;
            mybgimg.style.left=myleft+"10px";
        } 
});

document.getElementById("dbgimg").addEventListener("keyup", function(ev){
    console.log(ev.keyCode);
    if(ev.keycode== 13){
        createDiv();
    }
    if(ev.input== "mount")
        {
            document.backgroundImage.src="bg3.jpg";
        }
    else if(ev.input== "horse"){
         document.backgroundImage.src="bg1.jpg";
    }
    else if(ev.input== "night"){
         document.backgroundImage.src="bg2.jpg";
    }
    else if(ev.input== "epic"){
         document.backgroundImage.src="bg4.jpg";
    }
    
});


document.getElementById("title").addEventListener("keyup", function(ev){
    document.getElementById("dtitle").innerHTML = document.getElementById("title").value+"";
});

document.getElementById("para").addEventListener("keyup", function(ev){
    document.getElementById("dpara").innerHTML = document.getElementById("para").value+"";
});

/*
function changecolor(){
    
    
}
*/


function createDiv(){
    var newdiv = document.createElement("div");
    document.getElementById("dbgimg").appendChild(newdiv);
    newdiv.style.backgroundSize = "cover";
    newdiv.style.width = "100px";
    newdiv.style.height = "100px";
    newdiv.style.backgroundImage = "url("+srcStr+")";
    newdiv.style.display = "inline-block";
    newdiv.className = "col-12 col-sm-6 col-md-4 col-lg-3";
}



