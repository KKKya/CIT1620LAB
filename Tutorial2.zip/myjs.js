document.getElementById("open").addEventListener("click",
function(){
	document.getElementById("control").style.left="0px";
});

document.getElementById("0").addEventListener("click",
function(){
	document.getElementById("bgimg").style.backgroundImage = "url(IMGG/0.png)";
});

document.getElementById("1").addEventListener("click",
function(){
	document.getElementById("bgimg").style.backgroundImage = "url(IMGG/1.jpg)";
});

document.getElementById("2").addEventListener("click",
function(){
	document.getElementById("bgimg").style.backgroundImage = "url(IMGG/2.jpg)";
});

document.getElementById("3").addEventListener("click",
function(){
	document.getElementById("bgimg").style.backgroundImage = "url(IMGG/3.jpg)";
})

document.getElementById("close").addEventListener("click",
function(){
	document.getElementById("control").style.left="-200px";
});