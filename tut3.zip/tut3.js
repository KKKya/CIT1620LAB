var chatStr = ""

function replaceEmojis(){
    chatStr = chatStr.replace(":)", "<img class='emoji' src='smile.jpg' />");
    
    chatStr = chatStr.replace(":(", "<img class='emoji' src='sad.jpg' />");
    
    chatStr = chatStr.replace(">:|", "<img class='emoji' src='angry.jpg' />");
    
    chatStr = chatStr.replace(":D", "<img class='emoji' src='LOL.jpg' />");
    
    chatStr = chatStr.replace("|", "<img class='emoji' src='NO.jpg' />");
    
    
    chatStr = chatStr.replace("fudge","****")
    chatStr = chatStr.replace("dumb","****")
    chatStr = chatStr.replace("shit","****")
}

/*----------------p1chat---------------*/
function changeChatStr(){
    chatStr = document.getElementById("p1input").value;
    document.getElementById("p1input").value ="";
    
    /*if(chatStr ==":)"){
        chatStr ="<img class='emoji' src='smile.jpg' />";
        
    } else if(chatStr ==":("){
        chatStr = "<img class='emoji' src='sad.jpg' />";
    }
    */
    replaceEmojis();
}

/*----------------p2chat---------------*/
function changeChatStr2(){
    chatStr = document.getElementById("p2input").value;
    document.getElementById("p2input").value ="";
    
    replaceEmojis();
}


/*--------------chatdisplay-----------*/
function createChat(chatID){
    var ndiv = document.createElement("div");
    ndiv.innerHTML = chatStr;
    
    if(chatID == 1){
        ndiv.style.backgroundColor = "#AFA";
    } else if (chatID == 2){
        ndiv.style.backgroundColor = "#AAF";
    }
    
    ndiv.style.padding = "10px";
    ndiv.style.margin = "5px";
    
    document.getElementById("chatdisplay").appendChild(ndiv);
}


/*--------------Interactions-------------*/
document.getElementById("p1input").addEventListener("keyup",function(ev){
    if (ev.keyCode == 13){
        changeChatStr();
        createChat(1);
    }
})


/*--------------Interactions-------------*/
document.getElementById("p2input").addEventListener("keyup",function(ev){
    if (ev.keyCode == 13){
        changeChatStr2();
        createChat(2);
    }
})



